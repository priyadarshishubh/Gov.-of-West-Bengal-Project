<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Footer</title>
    <style>
        td,th {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 12px;
            width: 100%;
            position: absolute;
            bottom: 0px;
        }
    </style>
</head>
<body style="margin: 0 0 0 0;">
<table width="100%" border="0" cellspacing="0" cellpadding="00">
    <tr>
        <td style="padding:5px;"></td></tr>
    <tr>
        <td bgcolor="#333333" style="padding:5px;"><span style="color: #FFFFFF;">&copy; All Rights Reserved. Directorate of Industrial Training, Govt. of West Bengal </span></td>
    </tr>
</table>
</body>
</html>