<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Header</title>
  <style>
    td,th {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 12px;
    }
  </style>
</head>
<body style="margin: 0 0 0 0;">

<div style="background-color:white; display: block; margin: 0; width: 100%; position: absolute; top: 0; border-bottom: 1px solid #000;">
    <div style="float: left; margin: 0.3% 2% 0.1% 1%;">
        <img src="img/picture.png" width="101" height="100" />
    </div>
    <div style="transform: translate(0%, 22%);">
        <h2 style="display: inline-block; margin: 0; padding: 0; color: #3366FF;">Quality Monitoring Framework for Govt. ITI running under PPP</h2><br />
        <p style="margin: 0; padding: 0; font-size: 10px;">Department of Technical Education, Training &amp; Skill Development<br />
            Directorate of Industrial Training<br />
            Govt. of West Bengal
        </p>
    </div>
</div>


<!--          <table class="" width="100%" border="0" cellspacing="0" cellpadding="5" style="border-bottom:1px solid #333333;">-->
<!--              <tr>-->
<!--                  <td width="9%"><img src="/iti_spoc/img/picture.png" width="101" height="100" /></td>-->
<!--                  <td width="81%"><span style="font-size: 24px; font-weight: bold; color: #3366FF;">Quality Monitoring System</span><br />-->
<!--                      Department of Technical Education, Training &amp; Skill Development<br />-->
<!--                      Directorate of Industrial Training<br />-->
<!--                      Govt. og-->
<!--                      West Bengal </td>-->
<!--                  <td width="10%">&nbsp;</td>-->
<!--              </tr>-->
<!--          </table>-->
</body>
</html>

